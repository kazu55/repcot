print("about\n")
print("Uses Wojble's font")
print("Uses basalt GUI API")
sleep(2)
